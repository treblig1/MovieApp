import axios from "axios";

const movieDB = axios.create({
    baseURL: 'https://api.themoviedb.org/3/movie',
    params: {
        api_key: '9744e535b2335f94c84b2348c66a13ce',
        language: 'es-ES'
    }
})

export default movieDB;