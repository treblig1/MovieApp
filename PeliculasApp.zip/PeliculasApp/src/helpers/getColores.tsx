import ImageColors from 'react-native-image-colors';


 export const getImageColors = async (uri: string) => {

    let primary;
    let secundary;

    const colors = await ImageColors.getColors(uri, {});
    
    switch (colors.platform) {
        case 'android':
          // android result properties
          const vibrantColor = colors.vibrant
          primary = colors.dominant
          secundary = colors.average
          break
        case 'web':
          // web result properties
          const lightVibrantColor = colors.lightVibrant
          break
        case 'ios':
          // iOS result properties
          const primaryColor = colors.primary
          primary = colors.primary
          secundary = colors.secondary
          break
        default:
          throw new Error('Unexpected platform key')
      }
    
    return [primary, secundary]
}